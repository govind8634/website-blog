<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Form</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="custom-new.css">
    <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
    <style>
        .error {
            color: #FF0001;
            font-size: 12px;
        }
    </style>
</head>
<body>
    <section>
        <div class="container-fluid">
            <div class="container main-div">
                <div class="row">
                    <div class="col-12">
                        <form method="post">
                            <div class="details-page">
                                <h2>MM KHAMBHATWALA</h2>
                                <h3>Payment Form</h3>
                            </div>
                            <div class="mb-3">
                                <label for="companiname" class="form-label">Company Name</label>
                                <span class="error">* <?php echo $companinameErr; ?> </span>
                                <input type="text" placeholder="Company Name" class="form-control" id="companiname" name="companiname">
                            </div>
                            <div class="mb-3">
                                <label for="mobile" class="form-label">Mobile Number</label>
                                <span class="error">* <?php echo $mobileErr; ?> </span>
                                <input type="number" placeholder="Mobile Number" class="form-control" id="mobile" name="mobile">
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <span class="error">* <?php echo $emailErr; ?> </span>
                                <input type="email" placeholder="Email" class="form-control" id="email" name="email">
                            </div>
                            <div class="mb-3">
                                <label for="amount" class="form-label">Amount</label>
                                <span class="error">* <?php echo $amountErr; ?> </span>
                                <input type="number" placeholder="Amount" class="form-control" id="ex-gst" name="amount" onChange="updatePrice()">
                            </div>
                            <div class="mb-3">
                                <label for="invoice" class="form-label">Invoice Number</label>
                                <input type="text" placeholder="Invoice Number" class="form-control" id="invoice" name="invoice">
                            </div>
                            <div class="mb-3">
                                <label for="refrence" class="form-label">Ref. No</label>
                                <input type="text" placeholder="Ref. No" class="form-control" id="refrence" name="refrence">
                            </div>
                            <div class="row">
                                <div class="col-8 col-xs-12">
                                    <button type="submit" name="submit" class="btn second-btn btn-primary">DEBIT CREDIT CARD</button><br>
                                    <div class="row">
                                        <div class="col-auto col-sm-5">
                                            <small class="small-text">(3% extra charges will be applicable by the payment gateway provider)</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</body>

</html>

<?php
session_start();

// Assign values to variables
$companiname = "Company Name";  // Replace with actual value
$mobile = "1234567890";         // Replace with actual value
$email = "example@example.com"; // Replace with actual value
$amount = 100;                  // Replace with actual value
$invoice = "Invoice Number";    // Replace with actual value
$refrence = "Reference Number"; // Replace with actual value

// Set session values
$_SESSION['companiname'] = $companiname;
$_SESSION['mobile'] = $mobile;
$_SESSION['email'] = $email;
$_SESSION['amount'] = $amount;
$_SESSION['invoice'] = $invoice;
$_SESSION['refrence'] = $refrence;

// Redirect to the second page
header("Location: phonepe.php");
exit;
?>
