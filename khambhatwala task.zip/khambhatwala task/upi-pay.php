<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="custom.css">
    <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<?php
// Start the session
session_start();

// Access the unique ID stored in the session
$uniqueID = isset($_SESSION['unique_id']) ? $_SESSION['unique_id'] : 'No unique ID found';
echo $uniqueID;
?>

    <section>
        <div class="img-div">
            <p>UPI ID:&nbsp;mmkhambhatwala@kotak</p>
            <div class="img-div">
            <img src="image/qr.jpeg" alt="QR-CODE">
            </div>
            <div>
                <form method="POST" class="upi-form" action="" enctype="multipart/form-data">
                <input type="file" id="file" name="file">
                <button class="float-right btn btn-primary" name="upload" id="upload">Upload</button><br><br>
                <button class="float-right btn btn-primary" name="submit">Submit</button>
                </form>
            </div>
        </div>
    </section>
</body>
</html>

<?php
error_reporting(0);
 
$msg = "";
 
// If upload button is clicked ...
if (isset($_POST['upload'])) {
 
    $filename = $_FILES["file"]["name"];
    $tempname = $_FILES["file"]["tmp_name"];
    $folder = "./userphoto/" . $filename;
 
    $db = mysqli_connect("localhost", "root", "", "khambatdb");
 
    // Get all the submitted data from the form
    $sql = "INSERT INTO fileupload (file) VALUES ('$filename')";
 
    // Execute query
    mysqli_query($db, $sql);
 
    // Now let's move the uploaded image into the folder: image
    if (move_uploaded_file($tempname, $folder)) {
        echo "<h3>  Image uploaded successfully!</h3>";
    } else {
        echo "<h3>  Failed to upload image!</h3>";
    }
}
?>

<?php
$servername="localhost";
$username="root";
$password="";
$dbname="khambatdb";
 $conn= new mysqli($servername,$username,$password,$dbname);
 if($conn->connect_error){ 
    die("connection fail:".$conn->connect_error);
 }

$table = "uploaddata";
$lastrow = mysqli_query($conn,"SELECT * FROM $table ORDER BY id DESC LIMIT 1");
$get_last_row = mysqli_fetch_array($lastrow);

$table2 = "fileupload";
$endrow = mysqli_query($conn,"SELECT * FROM $table2 ORDER BY id DESC LIMIT 1");
$get_last_row2 = mysqli_fetch_array($endrow);
// echo "<div>";
// echo "<p>"."<span>"."Companiname -"."</span>".$get_last_row[1]."</p>";
// echo  "<p>"."<span>"."Mobile -"."</span>".$get_last_row[2]."</p>";
// echo  "<p>"."<span>"."Email -"."</span>".$get_last_row[3]."</p>";
// echo  "<p>"."<span>"."Amount -"."</span>".$get_last_row[4]."</p>";
// echo  "<p>"."<span>"."Invoice -"."</span>".$get_last_row[5]."</p>";
// echo  "<p>"."<span>"."Refrence -"."</span>".$get_last_row[6]."</p>";
// echo  "<p>"."<span>"."image -"."</span>".$get_last_row2[1]."</p>";
// echo "</div>";


//Import PHPMailer classes into the global namespace
//These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/Exception.php';
require 'phpmailer/PHPMailer.php';
require 'phpmailer/SMTP.php';

//Create an instance; passing `true` enables exceptions
$mail = new PHPMailer(true);

try {
    //Server settings
    // $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'mahawargovind191@gmail.com';                     //SMTP username
    $mail->Password   = 'kzncfccpjzbcocld';                               //SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
    $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setFrom('mahawargovind191@gmail.com', 'Mr.Govind Mahavar');
    $mail->addAddress($get_last_row[3]);     //Add a recipient
    // $mail->addAddress('ellen@example.com');               //Name is optional
    // $mail->addReplyTo('info@example.com', 'Information');
    // $mail->addCC('cc@example.com');
    // $mail->addBCC('bcc@example.com');

    //Attachments
    // $mail->addAttachment($get_last_row2[1]);   //Add attachments
    // $mail->addAttachment($filename);    //Optional name

    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = 'Dear '.$get_last_row[1].' User Your Payment Receive Sucessfully';
    $mail->Body    = 'Hello User Registration Successfully';
    $mail->Body    = "<p>"."<span>"."Companiname -"."</span>".$get_last_row[1]."</p>"."<br>"."<p>"."<span>"."Mobile -"."</span>".$get_last_row[2]."</p>"."<br>"."<p>"."<span>"."Email -"."</span>".$get_last_row[3]."</p>"."<br>"."<p>"."<span>"."Amount -"."</span>".$get_last_row[4]."</p>"."<br>"."<p>"."<span>"."Invoice -"."</span>".$get_last_row[5]."</p>"."<br>"."<p>"."<span>"."Refrence -"."</span>".$get_last_row[6]."</p>";
    // $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';


    if (isset($_POST['submit'])) {
        $mail->send();
    echo 'Message has been sent';
    }
        
} 

catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}

?>