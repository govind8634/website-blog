<?php
$servername="localhost";
$username="root";
$password="";
$dbname="upload";
 $conn= new mysqli($servername,$username,$password,$dbname);
 if($conn->connect_error){ 
    die("connection fail:".$conn->connect_error);
 }

$table = "uploaddata";
$lastrow = mysqli_query($conn,"SELECT * FROM $table ORDER BY id DESC LIMIT 1");
$get_last_row = mysqli_fetch_array($lastrow);
echo "<div>";
echo "<p>"."<span>"."Companiname -"."</span>".$get_last_row[1]."</p>";
echo  "<p>"."<span>"."Mobile -"."</span>".$get_last_row[2]."</p>";
echo  "<p>"."<span>"."Email -"."</span>".$get_last_row[3]."</p>";
echo  "<p>"."<span>"."Amount -"."</span>".$get_last_row[4]."</p>";
echo  "<p>"."<span>"."Invoice -"."</span>".$get_last_row[5]."</p>";
echo  "<p>"."<span>"."Refrence -"."</span>".$get_last_row[6]."</p>";
echo "</div>";

// echo $get_last_row[1];

?>