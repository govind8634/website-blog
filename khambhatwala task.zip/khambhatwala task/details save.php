<?php
include 'config.php';

// Start the session
session_start();

// Assuming you have a unique ID, for example, retrieved from a database or generated somehow
function generateUniqueID($length = 15) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $id = '';

    for ($i = 0; $i < $length; $i++) {
        $id .= $characters[rand(0, strlen($characters) - 1)];
    }

    return $id;
}

$uniqueID = generateUniqueID();
// echo $uniqueID;

// Store the unique ID in the session
$_SESSION['unique_id'] = $uniqueID;

$companinameErr = $mobileErr = $emailErr = $amountErr = "";
$companiname = $mobile = $email = $amount = "";

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    // company name validation
    if (empty($_POST["companiname"])) {
        $companinameErr = "Company name is required";
    } else {
        $companiname = input_data($_POST["companiname"]);
        // check if name only contains letters and whitespace
        if (!preg_match("/^[a-zA-Z ]*$/", $companiname)) {
            $companinameErr = "Only alphabets and white space are allowed";
        }
    }

    // mobile number validation
    if (empty($_POST["mobile"])) {
        $mobileErr = "Mobile number is required";
    } else {
        $mobile = input_data($_POST["mobile"]);
        // check if mobile no is well-formed
        if (!preg_match("/^[0-9]*$/", $mobile)) {
            $mobileErr = "Only numeric value is allowed.";
        }
        // check mobile no length should not be less and greater than 10
        if (strlen($mobile) != 10) {
            $mobileErr = "Mobile number must contain 10 digits.";
        }
    }

    // email validation
    if (empty($_POST["email"])) {
        $emailErr = "Email is required";
    } else {
        $email = input_data($_POST["email"]);
        // check that the e-mail address is well-formed
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $emailErr = "Invalid email format";
        }
    }

    // amount validation
    if (empty($_POST['amount'])) {
        $amountErr = "Amount is required";
    } else {
        $amount = input_data($_POST["amount"]);
    }
}

function input_data($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

if (empty($companinameErr) && empty($mobileErr) && empty($emailErr) && empty($amountErr)) {
    // $text = $amount*7/100;

    if (!empty($_POST['companiname'])) {
        $sql = "INSERT INTO uploaddata(unique_id,companiname,mobile,email,amount,invoice,refrence)VALUES('$uniqueID','" . $_POST['companiname'] . "','" . $_POST['mobile'] . "','" . $_POST['email'] . "','" . $_POST['amount'] . "','" . $_POST['invoice'] . "','" . $_POST['refrence'] . "')";
        if ($conn->query($sql) == true) {
            echo "Inserted successfully";
        } else {
            echo "Error: " . $sql . $conn->error;
        }
    }

    if (isset($_POST['upi'])) {
        // Store data in session
        $_SESSION['unique_id'] = $uniqueID;
        $_SESSION['companiname'] = $companiname;
        $_SESSION['mobile'] = $mobile;
        $_SESSION['email'] = $email;
        $_SESSION['amount'] = $amount;
        // $_SESSION['invoice'] = $invoice2;
        // $_SESSION['refrence'] = $refrence2;

        // Redirect to the second page
        header('location:./phonepe.php');
    }
}

    ?>

    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="custom.css">
        <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
        <style>  
    .error {color: #FF0001;font-size: 12px;}  
    </style> 
    </head>
    <body>
        <section>
            <div class="container-fluid">
                <div class="container main-div">
                    <div class="row">
                        <div class="col-12">
                            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                                <div class="details-page"> 
                                <h2>MM KHAMBHATWALA</h2>
                                <h3>Payment Form</h3>
                                </div>
                                <!-- <span class = "error">* required field </span> -->
                                <div class="mb-3">
                                    <label for="Company Name" class="form-label">Company Name</label>
                                    <span class="error">* <?php echo $companinameErr; ?> </span>  
                                    <input type="text" placeholder="Company Name" class="form-control" id="companiname" name="companiname">
                                </div>
                                <div class="mb-3">  
                                    <label for="mobile" class="form-label">Mobile Number</label>
                                    <span class="error">* <?php echo $mobileErr; ?> </span>
                                    <input type="number" placeholder="Mobile Number" class="form-control" id="mobile" name="mobile">
                                </div>
                                <div class="mb-3"> 
                                <label for="email" class="form-label">Email</label>
                                <span class="error">* <?php echo $emailErr; ?> </span>
                                <input type="email"placeholder="Email" class="form-control" id="email" name="email">
                                </div>
                                <div class="mb-3"> 
                                    <label for="amount" class="form-label">Amount</label>
                                <span class="error">* <?php echo $amountErr; ?> </span>
                                    <input type="number" placeholder="Amount" class="form-control" name="amount">
                                </div>
                                <div class="mb-3">
                                    <label for="invoice" class="form-label">Invoice Number</label>
                                    <input type="text" placeholder="Invoice Number" class="form-control" id="invoice" name="invoice">
                                </div>
                                <div class="mb-3">
                                    <label for="Ref" class="form-label">Ref. No</label>
                                    <input type="text" placeholder="Ref. No" class="form-control" id="refrence" name="refrence">
                                </div>
                                <div class="row">
                                <div class="col-8 col-xs-12">
                                <button type="submit" name="upi" class="btn second-btn btn-primary">DEBIT CREDIT CARD</button><br>
                               <div class="row">
                                <div class="col-auto col-sm-5">
                                <small class="small-text">(3% extra charges will be applicable by payment gateway provider)</small>
                                </div>
                               </div>
                                </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
    </body>
    </html>