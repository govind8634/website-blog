<?php
session_start();

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Access data from the session
$uniqueID = $_SESSION['unique_id'];
$companiname = $_SESSION['companiname'];
$mobile = $_SESSION['mobile'];
$email = $_SESSION['email'];
$amount = $_SESSION['amount'];

include 'config.php';

// Convert uniqueID to prevent SQL injection (optional but recommended)
$uniqueID = $conn->real_escape_string($uniqueID);

// Construct SQL query with a WHERE clause
$sql = "SELECT * FROM uploaddata WHERE unique_id = '$uniqueID'";

$result = $conn->query($sql);

$paymentData = [];

if ($result) {
    if ($result->num_rows > 0) {
        // Output data of each row
        $row = $result->fetch_assoc();
        // echo "Unique ID: " . $row["unique_id"]. "<br>";
        // echo "Company Name: " . $row["companiname"]. "<br>";
        // echo "Mobile: " . $row["mobile"]. "<br>";
        // echo "Email: " . $row["email"]. "<br>";
        // echo "Amount: " . $row["amount"]. "<br>";
        // echo "Invoice: " . $row["invoice"]. "<br>";
        // echo "Refrence: " . $row["refrence"]. "<br>";

        // Create the $paymentData array after fetching the row
        $paymentData = [
            'merchantId' => "Order id :- " .$row["unique_id"],
            'shortName' => "Name :- " .$row["companiname"],
            'mobileNumber' => "Mobile No :- " .$row["mobile"],
            'email' => "Email Id :- " .$row["email"],
            'amount' => "Amount :- " .$row["amount"],
            'message' => "Invoice :- " .$row["invoice"],
            'message2' => "Refrence :- " .$row["refrence"],
        ];
    } else {
        echo "0 results";
    }
} else {
    echo "Query failed: " . $conn->error;
}

$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Successful</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        .container-payment {
            /* text-align: center; */
            background-color: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        table, th, td {
  border: 1px solid grey;
  color: gray;
  border-collapse: collapse;
}

        h1 {
            color: #0ed678;
        }

        th, td {
  padding: 7px;
}

.container-payment p img{width: 70px;}
.container-payment p{text-align: center;}
        p {
            font-size: 18px;
            color: #333333;
        }

        .table-td{text-align: left;}

        .button {
            display: inline-block;
            padding: 10px 20px;
            margin-top: 20px;
            font-size: 16px;
            text-decoration: none;
            color: #ffffff;
            background-color: #0ed678;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="container-payment">
        <p><img src="image/check.png" alt="check"></p>
        <h1>Payment Successful</h1>
        <p>Thank you for your payment!</p>
        <table border="1" width="100%" class="table-td">
        <thead>
            <tr>
                <th>Your Details</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($paymentData as $value): ?>
                <tr>
                    <td><?php echo $value; ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
        <a href="#" class="button">&#8592;</a>
    </div>
</body>
</html>
