<?php

    require 'upload.php';
    require 'send.php';

    // sending query
    $result = mysql_query("SELECT ID,TOOLS,SN,EXPIRATION_DATE,USER_EMAIL FROM uploaddata WHERE MONTH(EXPIRATION_DATE) = 8  AND YEAR(EXPIRATION_DATE) = YEAR(now()) ");
    if (!$result) {
        die("Query to show fields from table failed");
    }

    $result2 = mysql_query("SELECT ID,TOOLS,SN,EXPIRATION_DATE,USER_EMAIL FROM fileupload WHERE MONTH(EXPIRATION_DATE) = 8  AND YEAR(EXPIRATION_DATE) = YEAR(now()) ");
    if (!$result2) {
        die("Query to show fields from table failed");
    }

    $result.$result2 = $result3;


    $fields_num = mysql_num_fields($result3);

    echo "<table border='1'><tr>";
    echo "<table class='hovertable'>";
    // printing table headers

    for($i=0; $i<$fields_num; $i++)
    {
        $field = mysql_fetch_field($result3);
        echo "<th>{$field->name}</th>";
    }
    echo "</tr>\n";
    // printing table rows
    while($row = mysql_fetch_row($result3))
    {
        echo "<tr>";

              foreach($row as $cell)
            echo "<td>$cell</td>";

        echo "</tr>\n";
    }
    mysql_free_result($result3);
    
    ?>

    <?php
    
     $to = "infogovind191@gmail.com";
     $subject = "Test mail";
     $message = "This is testing mail send";
     $from = "mahawargovind191@gmail.com";
     $headers = "from: $from";

     $mail($to,$subject,$message,$headers);
    echo "mail send sucessfully";

    ?>