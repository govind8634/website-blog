<?php
$merchantId = 'PGTESTPAYUAT';
$apiKey = "099eb0cd-02cf-4e2a-8aca-3e6c6aff0399";
$redirectUrl = 'https://thynkcrm.com/pp/payment-success.php';

session_start();

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Access data from the session
$uniqueID = $_SESSION['unique_id'];
$companiname = $_SESSION['companiname'];
$mobile = $_SESSION['mobile'];
$email = $_SESSION['email'];
$amount = $_SESSION['amount'];

include 'config.php';

// Convert uniqueID to prevent SQL injection (optional but recommended)
$uniqueID = $conn->real_escape_string($uniqueID);

// Construct SQL query with a WHERE clause
$sql = "SELECT * FROM uploaddata WHERE unique_id = '$uniqueID'";

$result = $conn->query($sql);

$paymentData = [];

if ($result) {
    if ($result->num_rows > 0) {
        // Output data of each row
        $row = $result->fetch_assoc();
        // echo "Unique ID: " . $row["unique_id"]. "<br>";
        // echo "Company Name: " . $row["companiname"]. "<br>";
        // echo "Mobile: " . $row["mobile"]. "<br>";
        // echo "Email: " . $row["email"]. "<br>";
        // echo "Amount: " . $row["amount"]. "<br>";
        // echo "Invoice: " . $row["invoice"]. "<br>";
        // echo "Refrence: " . $row["refrence"]. "<br>";

        // Create the $paymentData array after fetching the row
        $paymentData = [
            'merchantId' => "Order id :- " .$row["unique_id"],
            'shortName' => "Name :- " .$row["companiname"],
            'mobileNumber' => "Mobile No :- " .$row["mobile"],
            'email' => "Email Id :- " .$row["email"],
            'amount' => "Amount :- " .$row["amount"],
            'message' => "Invoice :- " .$row["invoice"],
            'message2' => "Refrence :- " .$row["refrence"],
        ];
    } else {
        echo "0 results";
    }
} else {
    echo "Query failed: " . $conn->error;
}

$conn->close();

$order_id = $row["unique_id"];
$name = $row["companiname"];
$mobile = $row["mobile"];
$email = $row["email"];
$amount = $row["amount"];
$description = $row["invoice"];
$notes = $row["refrence"];

$paymentData = [
    'MerchantId' => $merchantId,
    'MerchantTransactionId' => "MT" . time(),
    'MerchantUserId' => $uniqueID,
    'ShortName' => $name,
    'MobileNumber' => $mobile,
    'Email' => $email,
    'Amount' => $amount * 100,
    'Message' => $description,
    'Notes' => $notes,
    'RedirectUrl' => $redirectUrl,
    'RedirectMode' => "POST",
    'CallbackUrl' => $redirectUrl,
    'MerchantOrderId' => $order_id,
    'PaymentInstrument' => [
        'type' => 'PAY_PAGE',
    ],
];

$jsonencode = json_encode($paymentData);
$payloadMain = base64_encode($jsonencode);
$salt_index = 1;
$payload = $payloadMain . "/pg/v1/pay" . $apiKey;
$sha256 = hash("sha256", $payload);
$final_x_header = $sha256 . '###' . $salt_index;
$request = json_encode(['request' => $payloadMain]);

$curl = curl_init();
curl_setopt_array($curl, [
    CURLOPT_URL => "https://api-preprod.phonepe.com/apis/pg-sandbox/pg/v1/pay",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "POST",
    CURLOPT_POSTFIELDS => $request,
    CURLOPT_HTTPHEADER => [
        "Content-Type: application/json",
        "X-VERIFY: " . $final_x_header,
        "accept: application/json",
    ],
]);

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
    echo "cURL Error #:" . $err;
} else {
    $res = json_decode($response);

    if (isset($res->success) && $res->success == '1') {
        $paymentCode = $res->code;
        $paymentMsg = $res->message;
        $payUrl = $res->data->instrumentResponse->redirectInfo->url;

        // Log the payment details or update your database as needed

        // Redirect to PhonePe for payment
        header('Location:' . $payUrl);
        exit();
    } else {
        // Handle payment failure
        echo "Payment failed: " . $res->message;
    }
}
?>
